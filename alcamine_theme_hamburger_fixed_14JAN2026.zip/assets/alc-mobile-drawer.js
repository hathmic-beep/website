/* ALC Mobile Drawer (Hamburger) - 2026-01-14 */
(function () {
  function qs(sel, ctx) { return (ctx || document).querySelector(sel); }
  function qsa(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  var openBtn = qs('[data-alc-drawer-open]');
  var drawer = qs('[data-alc-drawer]');
  if (!openBtn || !drawer) return;

  var closeBtn = qs('[data-alc-drawer-close]', drawer);
  var backdrop = qs('[data-alc-drawer-backdrop]', drawer);
  var panel = qs('.alc-mobile-drawer__panel', drawer);

  var lastActive = null;

  function setExpanded(isOpen) {
    openBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  }

  function openDrawer() {
    lastActive = document.activeElement;
    drawer.hidden = false;
    document.body.classList.add('alc-drawer-open');
    setExpanded(true);

    // Focus first focusable control in panel
    var focusables = getFocusable(panel);
    (focusables[0] || panel).focus({ preventScroll: true });

    document.addEventListener('keydown', onKeydown);
    drawer.addEventListener('click', onClickOutside);
  }

  function closeDrawer() {
    drawer.hidden = true;
    document.body.classList.remove('alc-drawer-open');
    setExpanded(false);

    document.removeEventListener('keydown', onKeydown);
    drawer.removeEventListener('click', onClickOutside);

    if (lastActive && typeof lastActive.focus === 'function') {
      lastActive.focus({ preventScroll: true });
    }
  }

  function onClickOutside(e) {
    // Backdrop and explicit close button handle closing. Avoid closing when clicking inside panel.
    if (e.target === backdrop) closeDrawer();
  }

  function onKeydown(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      closeDrawer();
      return;
    }
    // Simple focus trap
    if (e.key === 'Tab') {
      var focusables = getFocusable(panel);
      if (!focusables.length) return;
      var first = focusables[0];
      var last = focusables[focusables.length - 1];

      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  }

  function getFocusable(root) {
    return qsa('a[href], button:not([disabled]), details > summary, input, select, textarea, [tabindex]:not([tabindex="-1"])', root)
      .filter(function (el) { return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length); });
  }

  openBtn.addEventListener('click', function () {
    if (!drawer.hidden) closeDrawer();
    else openDrawer();
  });

  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  if (backdrop) backdrop.addEventListener('click', closeDrawer);

  // Close drawer when a link is clicked (common UX expectation)
  drawer.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a') : null;
    if (a && drawer.contains(a)) closeDrawer();
  });

  // Defensive: if resized to desktop, ensure drawer closes
  window.addEventListener('resize', function () {
    if (window.matchMedia('(min-width: 901px)').matches && !drawer.hidden) closeDrawer();
  });
})();