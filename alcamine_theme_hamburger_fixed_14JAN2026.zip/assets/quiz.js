document.addEventListener("DOMContentLoaded", function () {
  const steps = document.querySelectorAll(".alc-quiz__step");
  const resultBox = document.getElementById("quizResult");
  const resultText = document.getElementById("resultText");
  const resultButton = document.getElementById("resultButton");

  if (!steps.length || !resultBox) {
    // Not on the quiz page, exit safely
    return;
  }

  let currentStep = 1;
  let selectedProtocol = null;

  function showStep(num) {
    steps.forEach((step) => step.classList.remove("active"));
    const target = document.querySelector(`.alc-quiz__step[data-step="${num}"]`);
    if (target) {
      target.classList.add("active");
    }
  }

  // Show first question
  showStep(1);

  // First step: picks a protocol
  document.querySelectorAll("[data-result]").forEach((btn) => {
    btn.addEventListener("click", function () {
      selectedProtocol = btn.getAttribute("data-result");
      currentStep = 2;
      showStep(currentStep);
    });
  });

  // Other steps: just go to next
  document.querySelectorAll("[data-next]").forEach((btn) => {
    btn.addEventListener("click", function () {
      currentStep += 1;
      if (currentStep <= steps.length) {
        showStep(currentStep);
      }

      // After last step, show result
      if (currentStep > steps.length) {
        showResult();
      }
    });
  });

  function showResult() {
    steps.forEach((s) => s.classList.remove("active"));
    resultBox.style.display = "block";

    let text = "";
    let link = "#";

    if (selectedProtocol === "focus") {
      text = "You need the Focus & Mental Clarity Protocol.";
      link = "/products/alcamine-focus-stack";
    } else if (selectedProtocol === "gut") {
      text = "You need the Gut Reset Protocol.";
      link = "/products/alcamine-gut-reset";
    } else if (selectedProtocol === "stress") {
      text = "You need the Calm & Stress Support Protocol.";
      link = "/products/alcamine-calm-stack";
    } else if (selectedProtocol === "sleep") {
      text = "You need the Deep Sleep & Recovery Protocol.";
      link = "/products/alcamine-sleep-stack";
    } else if (selectedProtocol === "energy") {
      text = "You need the Daily Energy Protocol.";
      link = "/products/alcamine-energy-stack";
    } else {
      text = "We recommend starting with our Core Daily Essentials.";
      link = "/collections/all";
    }

    resultText.textContent = text;
    resultButton.href = link;
  }
});
