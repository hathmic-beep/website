document.addEventListener("DOMContentLoaded", () => {
  const sliders = document.querySelectorAll(".alc-hero-slider");

  sliders.forEach((slider) => {
    const slides = slider.querySelectorAll(".alc-hero-slide");
    const dots = slider.querySelectorAll(".alc-hero-slider__dot");

    if (slides.length <= 1) return;

    let current = 0;
    const autoplay = slider.dataset.autoplay === "true";
    const interval = parseInt(slider.dataset.interval, 10) || 5000;
    let timer = null;

    const activate = (index) => {
      slides.forEach((slide, i) => {
        slide.classList.toggle("is-active", i === index);
      });
      dots.forEach((dot, i) => {
        dot.classList.toggle("is-active", i === index);
      });
      current = index;
    };

    const next = () => {
      const nextIndex = (current + 1) % slides.length;
      activate(nextIndex);
    };

    /* --- FIXED DOT CLICK HANDLER --- */
    dots.forEach((dot, index) => {
      dot.addEventListener("click", () => {
        activate(index);
        if (autoplay && timer) {
          clearInterval(timer);
          timer = setInterval(next, interval);
        }
      });
    });

    /* --- AUTOPLAY --- */
    if (autoplay) {
      activate(0);
      timer = setInterval(next, interval);
    }
  });
});
document.addEventListener("DOMContentLoaded", () => {
  const items = document.querySelectorAll(".js-alc-reveal");

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("revealed");
        }
      });
    },
    { threshold: 0.25 }
  );

  items.forEach((item) => observer.observe(item));
});
